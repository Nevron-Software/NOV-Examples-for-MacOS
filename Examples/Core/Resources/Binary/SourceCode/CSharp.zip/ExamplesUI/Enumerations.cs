﻿namespace Nevron.Nov.Examples
{
	/// <summary>
	/// Enumerates the programming languages supported by NOV examples.
	/// </summary>
	public enum ENProgrammingLanguage
	{
		CSharp,
		VisualBasic
	}
}